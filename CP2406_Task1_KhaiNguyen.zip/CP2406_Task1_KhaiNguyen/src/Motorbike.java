public class Motorbike extends Car {

    public Motorbike(String id) {
        this.id = ("bike_" + id);
        length = super.getLength() * 0.5f;

    }

    public Motorbike(String id, Road currentRoad) {
        super(id, currentRoad);
        length = super.getLength() * 0.5f;
    }

    public void printMotorbikeStatus()
    {
        super.printCarStatus();
    }

}
