public class Bus extends Car {

    private int number_of_passengers;
    private String fuel;

    public Bus(String id) {
        this.id = ("bus_" + id);
        length = super.getLength() * 3;
        number_of_passengers = 0;
        fuel = "oil";
    }

    public Bus(String id,Road currentRoad)
    {
        super(id, currentRoad);
        length = super.getLength() * 3;
        number_of_passengers = 0;
        fuel = "oil";
    }

    public Bus(String id, Road currentRoad, int number_of_passengers, String fuel) {
        super(id, currentRoad);
        length = super.getLength() * 3;
        this.number_of_passengers = number_of_passengers;
        this.fuel = fuel;
    }


    public void setNumber_of_passengers(int number_of_passengers) {
        this.number_of_passengers = number_of_passengers;
    }
    public int getNumber_of_passengers() { return number_of_passengers; }


    public void setFuel(String fuel) { this.fuel = fuel; }
    public String getFuel() { return fuel; }


    public void printBustStatus()
    {
        super.printCarStatus() ;
        System.out.print("\nAnd can carry" + this.number_of_passengers);
    }
}
