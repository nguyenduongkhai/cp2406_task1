# Traffic-Simulator-1.0
A console based simulation of traffic.
